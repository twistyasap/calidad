import React from 'react';
import { Phone, User, Calendar, Pill, AlertCircle } from 'lucide-react';
import type { Resident } from '../types';

interface ResidentCardProps {
  resident: Resident;
  onViewDetails: (id: string) => void;
  onEmergencyAlert: (resident: Resident) => void;
}

export function ResidentCard({ resident, onViewDetails, onEmergencyAlert }: ResidentCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center gap-4">
        <img
          src={resident.photo || 'https://images.unsplash.com/photo-1566616213894-2d4e1baee5d8?w=200&h=200&fit=crop'}
          alt={resident.name}
          className="w-20 h-20 rounded-full object-cover"
        />
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-gray-800">{resident.name}</h3>
          <div className="flex items-center gap-2 text-gray-600 mt-1">
            <Calendar className="w-4 h-4" />
            <span>{new Date(resident.dateOfBirth).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Pill className="w-4 h-4" />
            <span>{resident.medications.length} medications</span>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <button
            onClick={() => onViewDetails(resident.id)}
            className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors flex items-center gap-2"
          >
            <User className="w-4 h-4" />
            View Details
          </button>
          <button
            onClick={() => onEmergencyAlert(resident)}
            className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors flex items-center gap-2"
          >
            <AlertCircle className="w-4 h-4" />
            Alert
          </button>
        </div>
      </div>
    </div>
  );
}