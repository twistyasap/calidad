export interface Resident {
  id: string;
  name: string;
  dateOfBirth: string;
  photo: string;
  medicalConditions: string[];
  allergies: string[];
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  medications: Medication[];
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  schedule: {
    morning?: boolean;
    afternoon?: boolean;
    evening?: boolean;
  };
  taken: boolean;
  timeLastTaken?: string;
}